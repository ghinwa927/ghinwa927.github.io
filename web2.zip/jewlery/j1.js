function changeto(a){
    let aa=a;
    aa.style.background="black";
    aa.style.color="white";
}

function changeback(a){
    let aa=a;
    aa.style.background="white";
    aa.style.color="black";
}

function gotomen(){
    window.location.href="Men.html"
}

function gotowomen(){
    window.location.href="Women.html"
}